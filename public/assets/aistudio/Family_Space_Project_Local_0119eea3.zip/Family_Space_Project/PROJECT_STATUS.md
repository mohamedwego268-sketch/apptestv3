# حالة المشروع — Family Space

آخر تحديث: 2026-10-22

## المرحلة الحالية
نموذج HTML محلي تفاعلي؛ ليس تطبيق إنتاج ولا يحتوي على خادم أو حسابات حقيقية.

## المنفذ في النموذج
- واجهة عربية RTL متجاوبة مبدئيًا.
- ملفات الأطفال وتعديلها.
- الروتين اليومي، تصفية المهام، وتسجيل الإكمال.
- الأمنيات والهدايا (تجريبي).
- مساحة العائلة وصلاحيات توضيحية.
- المساعد بردود ثابتة غير متصلة بنموذج ذكاء اصطناعي.
- دليل خدمات تجريبي.
- تقويم أسري: إضافة/تعديل/حذف أحداث، ربط بطفل، تاريخ ووقت ونوع وملاحظات، فلاتر تاريخ، وبطاقة أقرب موعد في الصفحة الرئيسية.
- تصدير JSON ومسح البيانات المحلية.

## ما لم ينفذ
- حسابات ومصادقة حقيقية.
- خادم API وقاعدة بيانات مشتركة.
- صلاحيات مطبقة على الخادم.
- مزامنة بين أجهزة الأب والأم.
- إشعارات حقيقية أو تكرار آلي للأحداث.
- ذكاء اصطناعي متصل.
- حجوزات أو مدفوعات أو مزودون حقيقيون.
- اختبار متصفح شامل أو تدقيق أمني.

## آخر تغيير
أضيفت صفحة التقويم الأسري وبطاقة أقرب موعد في الصفحة الرئيسية. تم فحص صياغة JavaScript باستخدام `node --check` وفحوص وجود عناصر الميزة؛ هذا لا يعادل اختبارًا داخل متصفح. لم تتوفر حزمة اختبار متصفح (Playwright/Puppeteer) في بيئة العمل.

## قاعدة النشر
ممنوع رفع أو نشر المشروع على أي منصة إلا إذا غيّر المستخدم هذا القرار صراحةً. العمل محلي فقط.

## التالي
1. اختبار التفاعلات في متصفح حقيقي.
2. وضع مواصفات التنبيهات الفعلية قبل تنفيذها.
3. اعتماد نموذج البيانات والصلاحيات قبل بدء خادم الإنتاج.
4. إعداد مواصفات قاعدة البيانات والخادم بعد تثبيت نطاق النسخة الأولى.


## Update — design token foundation (2026-10-22)
- Added a documented design-token block to the prototype CSS.
- Added named mom/dad theme selectors and a starter high-contrast token set.
- Added `planning/DESIGN_SYSTEM_v1.1.md` and logged the remaining hard-coded styling risk.
- Status: partial tokenization only; inline colors and emoji icon placeholders remain. No external publishing or upload was performed.


## 2026-10-22 — Browser QA follow-up
- Applied targeted CSS/UX and error-handling fixes to the local prototype.
- Static validation passed: JavaScript syntax, HTML parse, IDs, navigation targets, inline handler references.
- Actual browser QA remains blocked because the connected Opera browser is not connected and local Chromium is blocked by environment policy. See `planning/BROWSER_QA_REPORT.md`.
- Rollback baseline: `prototype/index.pre-hardening.html`.


## Update — local data integrity hardening (2026-10-22)
- Deleting a child now warns about related tasks, calendar events, and wishes, then removes those linked demo records to avoid orphaned data.
- Startup normalization detaches invalid child references from tasks/events/wishes.
- Wishlist form validates a trimmed name, finite non-negative price, and a valid child reference; family member names are trimmed and checked.
- Browser-based visual/interaction QA is still pending; only static checks are claimed until a browser is connected.

## 2026-10-22 — Role-based color switching
- Fixed inconsistent automatic color switching between mother/father preview modes by expanding theme token overrides and making the hero role badge dynamic.
- Replaced fixed inline color on the father option with a named class.
- Static JS syntax and duplicate-ID checks passed. Real browser visual QA remains pending until the browser connector is available.
