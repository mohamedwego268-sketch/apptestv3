# سجل المشكلات والحلول — Family Space

آخر تحديث: 2026-10-22

## PS-001 — بيانات الطفل الحساسة
- **المشكلة:** صلاحيات عامة على مستوى العائلة قد تكشف بيانات صحية أو صورًا.
- **الحل المقترح:** صلاحيات دقيقة لكل نطاق بيانات، رفض الوصول افتراضيًا للبيانات الحساسة، والتحقق من الصلاحيات على الخادم في الإنتاج.
- **الحالة:** تصميم/تخطيط؛ نموذج الصلاحيات المحلي توضيحي وليس أمانًا فعليًا.

## PS-002 — ضياع التعديلات أو اختلاف النماذج
- **المشكلة:** نموذج ذكاء اصطناعي آخر قد يعدل نسخة قديمة أو يتجاوز قرارًا سابقًا.
- **الحل:** تسليم `AI_HANDOFF.md` و`DECISIONS.md` و`PROJECT_STATUS.md` مع الملفات؛ حفظ نسخة ZIP محلية قبل كل تغيير كبير؛ إدراج قائمة الملفات المتغيرة والاختبارات.
- **الحالة:** إجراء عمل معتمد. لا يوجد نشر خارجي.

## PS-003 — ترحيل بيانات النسخة السابقة
- **المشكلة:** البيانات القديمة قد لا تحتوي على خاصية `events` أو خصائص حديثة أخرى.
- **الحل:** إضافة تطبيع بسيط للبيانات عند القراءة، وإعطاء `events` مصفوفة فارغة إذا لم تكن موجودة.
- **الحالة:** مطبق في النموذج التجريبي. لا يُعد نظام ترحيل إنتاجيًا.

## PS-004 — التقويم والتذكيرات
- **المشكلة:** المستخدم قد يفهم اختيار التكرار أو الملاحظة كتذكير حقيقي.
- **الحل:** تسمية واضحة داخل الواجهة: التكرار يُحفظ كاختيار فقط ولا يولد أحداثًا تلقائية؛ لا توجد إشعارات نظامية أو مزامنة.
- **الحالة:** مطبق توضيحيًا. التذكيرات الفعلية تحتاج خدمة خلفية، صلاحيات، جدولة، وإعدادات إشعارات.

## PS-005 — الوقت والتاريخ المحلي
- **المشكلة:** تحويل التاريخ إلى UTC قد يعرض الموعد في يوم غير مقصود.
- **الحل:** تخزين التاريخ كـ `YYYY-MM-DD` محليًا في النموذج بدل تحويله إلى توقيت UTC.
- **الحالة:** مطبق في النموذج؛ يلزم تصميم موحد للمناطق الزمنية عند بناء الخادم.

## PS-006 — فقدان بيانات المتصفح
- **المشكلة:** حذف بيانات المتصفح أو تغيير الجهاز قد يمحو البيانات المحلية.
- **الحل:** تذكير المستخدم بأن البيانات محلية، مع تصدير JSON كنسخة احتياطية. لاحقًا: حسابات ومزامنة وخيارات تنزيل/حذف آمنة.
- **الحالة:** التصدير موجود؛ النسخ الاحتياطي التلقائي غير موجود.

## PS-007 — ثغرات حقن HTML
- **المشكلة:** عرض نصوص المستخدم داخل HTML قد يفتح بابًا لحقن عناصر أو سكربتات.
- **الحل:** استخدام دالة `esc` للنصوص الديناميكية المعروضة، وتجنب إدخال HTML غير موثوق. يلزم اختبار أمني أوسع قبل الإنتاج.
- **الحالة:** إجراء جزئي في النموذج؛ ليس تدقيقًا أمنيًا كاملًا.

## PS-008 — ادعاء اختبار لم يحدث
- **المشكلة:** فحص صياغة JavaScript وحده لا يثبت أن الواجهة تعمل في متصفح فعلي.
- **الحل:** تقارير الاختبار تميز بين فحص الصياغة، واختبار المتصفح، واختبار الأمان.
- **الحالة:** معتمد كقاعدة توثيق.

## PS-009 — الأحداث لا تظهر في لوحة البداية
- **المشكلة:** إذا أُضيف الحدث في صفحة التقويم فقط، قد لا يلاحظه المستخدم أثناء دخوله اليومي.
- **الحل:** إضافة بطاقة «أقرب موعد» إلى الصفحة الرئيسية مع رابط مباشر للتقويم.
- **الحالة:** مطبق في النموذج المحلي. لا توجد إشعارات استباقية أو تنبيهات خارج التطبيق.


## PS-010 — تصدير النسخة الاحتياطية والتحقق من الإدخال
- **المشكلة:** إلغاء رابط تنزيل ملف JSON فور الضغط قد يسبب فشلًا في بعض المتصفحات، كما يمكن إدخال أسماء فارغة بمسافات أو تاريخ ميلاد مستقبلي.
- **الحل:** تأخير إلغاء الرابط، وإظهار نتيجة التصدير، وتنظيف النصوص ورفض الأسماء الفارغة وتواريخ الميلاد المستقبلية.
- **الحالة:** مطبق؛ يحتاج اختبار تنزيل فعلي في متصفح متصل.


## 2026-10-22 — Referential cleanup and form validation
**Problem:** Removing a child could leave tasks, calendar events, and wishlist entries pointing at a deleted child. Wishlist and family-member forms also relied too heavily on browser-side validation.

**Mitigation:** Child deletion now summarizes linked items before confirmation and removes the related demo records together. Startup normalization detaches invalid child references in older/corrupt local data. Wishlist names/prices/child references and family-member names are validated in JavaScript before saving.

**Verification:** JavaScript syntax and static HTML checks are run after the patch. This is still not a browser interaction test.

## 2026-10-22 — Automatic role-color mismatch
**Observed:** Parent role switching did not recolor every dependent component consistently; the hero badge stayed rose-toned in dad mode, and some surfaces/controls were fixed to one palette.
**Cause:** Theme selectors overrode only a small subset of CSS variables, while a few components had static role-specific classes or inline colors.
**Fix:** Expanded mom/dad token sets; made the hero badge role-aware; replaced the inline dad-option color with a named CSS class.
**Validation:** `node --check` passed; HTML duplicate-ID scan passed; static checks confirm theme token declarations and role-aware hero class. Real browser visual verification is still pending because the browser connector is disconnected.
