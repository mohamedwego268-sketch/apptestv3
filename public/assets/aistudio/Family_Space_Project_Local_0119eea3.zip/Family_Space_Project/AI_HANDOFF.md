# AI Handoff — Family Space

## Instructions to the next AI
Continue the existing project rather than recreating it. Read `PROJECT_CHARTER.md`, `DECISIONS.md`, `PROJECT_STATUS.md`, and the planning files before editing.

## Hard constraint
**Local/offline work only. Never upload, publish, deploy, or push to GitHub/hosting.** Do not imply that local changes were tested in a real browser unless such a test actually ran.

## Product direction
- Arabic-first RTL responsive family/parenting platform.
- First market Egypt; design for future Saudi Arabia localization.
- Intended for parents/caregivers, not direct child use.
- Modular architecture; implement incrementally.
- Current HTML file is a prototype only, using localStorage and demo data.

## Current entry point
`prototype/index.html`

Other prototype: `prototype/permissions-flow-demo.html`.

## Current features
Children profiles, routines, static assistant examples, demo service directory, wishes, demo family permission toggles, settings/export/clear, and a local family calendar.

## Calendar limitations
Events are localStorage-only. Repeat value is descriptive only; no recurrence expansion, no push/system notifications, no account sync, and no backend. Keep these limitations visible in UI and documentation.

## Workflow required for every change
1. Identify user-facing goal and affected files.
2. Check existing architecture and backward compatibility.
3. Create/maintain a problem + mitigation entry for any discovered risk.
4. Make the smallest coherent change.
5. Run syntax checks and available tests; distinguish static checks from browser tests.
6. Update `PROJECT_STATUS.md`, `AI_HANDOFF.md`, and relevant specification.
7. Rebuild local ZIP, verify archive integrity, and report exact changed files, tests, known issues, and rollback path.
8. Never claim deployment or upload.

## Data safety
Sensitive child health/photos must default to private in the production design. Authorization must be enforced on the server, not merely in UI. Do not place API keys or secrets in frontend code.


## Latest work: design tokens
The prototype now has a documented CSS design-token block near the top of `prototype/index.html`, plus compatibility aliases to support incremental migration. Parent demo theme sets `document.documentElement.dataset.theme` to `mom` or `dad`. A `high-contrast` token selector exists but has no visible toggle yet. Read `planning/DESIGN_SYSTEM_v1.1.md` before visual edits. Important: tokenization is incomplete; inline styles and literal colors remain, and emoji are placeholder icons. Do not claim full design centralization or browser-tested behavior. Keep work local and do not publish/deploy.


## Latest handoff note — 2026-10-22
The current prototype has targeted QA fixes (mobile nav active state, keyboard focus, reduced-motion, narrow-layout safeguards, localStorage failure warning, calendar range validation). See `planning/BROWSER_QA_REPORT.md`. JavaScript syntax and static HTML checks passed. Do not claim browser interaction or visual QA: Opera connector was not connected and local Chromium was blocked. Rollback copy: `prototype/index.pre-hardening.html`. Additional hardening: JSON export cleanup is delayed safely; blank names are rejected and future child birth dates are blocked. Continue to work locally only; do not publish/upload/deploy.


## Latest work — data integrity (2026-10-22)
Child deletion now presents a count of linked demo tasks/events/wishes before cascading deletion. Startup normalization clears invalid child references, and wish/family-member forms validate inputs before writing to localStorage. This is prototype-only behavior; real production deletion requires transactional backend logic, authorization, retention policy, and auditability. Browser testing remains pending.
